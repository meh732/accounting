Set oWS = WScript.CreateObject("WScript.Shell")
sLinkFile = oWS.SpecialFolders("Desktop") & "\حسابداری مَه.lnk"
Set oLink = oWS.CreateShortcut(sLinkFile)
sCurrentDir = oWS.CurrentDirectory

If oWS.FileExists(sCurrentDir & "\Hesabdari-Meh-Client.exe") Then
    oLink.TargetPath = sCurrentDir & "\Hesabdari-Meh-Client.exe"
Else
    oLink.TargetPath = sCurrentDir & "\اجرای_حسابداری_مه.cmd"
End If

oLink.WorkingDirectory = sCurrentDir
oLink.Description = "نرم افزار حسابداری مَه - کلاینت ویندوز"
oLink.WindowStyle = 7
oLink.Save
WScript.Echo "میانبر حسابداری مَه با موفقیت روی دسکتاپ ویندوز ایجاد شد."
