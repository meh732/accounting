Set oWS = WScript.CreateObject("WScript.Shell")
sLinkFile = oWS.SpecialFolders("Desktop") & "\حسابداری مَه (کلاینت).lnk"
Set oLink = oWS.CreateShortcut(sLinkFile)
sCurrentDir = oWS.CurrentDirectory

If oWS.FileExists(sCurrentDir & "\Hesabdari-Meh-Client.exe") Then
    oLink.TargetPath = sCurrentDir & "\Hesabdari-Meh-Client.exe"
Else
    oLink.TargetPath = sCurrentDir & "\اجرای_کلاینت.cmd"
End If

oLink.WorkingDirectory = sCurrentDir
oLink.Description = "حسابداری مَه - کلاینت ویندوز"
oLink.Save
WScript.Echo "میانبر کلاینت حسابداری مَه با موفقیت روی دسکتاپ ایجاد شد."
