Set oWS = WScript.CreateObject("WScript.Shell")
sLinkFile = oWS.SpecialFolders("Desktop") & "\سرور حسابداری مَه.lnk"
Set oLink = oWS.CreateShortcut(sLinkFile)
sCurrentDir = oWS.CurrentDirectory

If oWS.FileExists(sCurrentDir & "\Hesabdari-Meh-Server.exe") Then
    oLink.TargetPath = sCurrentDir & "\Hesabdari-Meh-Server.exe"
Else
    oLink.TargetPath = sCurrentDir & "\شروع_سرور.cmd"
End If

oLink.WorkingDirectory = sCurrentDir
oLink.Description = "سرور مرکزی حسابداری مَه"
oLink.Save
WScript.Echo "میانبر سرور حسابداری مَه با موفقیت روی دسکتاپ ایجاد شد."
