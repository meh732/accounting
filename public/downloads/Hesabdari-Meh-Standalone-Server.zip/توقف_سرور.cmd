@echo off
chcp 65001 >nul
title توقف سرور حسابداری مَه
taskkill /f /im node.exe 2>nul
echo سرور با موفقیت متوقف شد.
pause
