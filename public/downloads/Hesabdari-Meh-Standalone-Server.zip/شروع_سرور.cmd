@echo off
chcp 65001 >nul
title سرور مرکزی حسابداری مَه
cd /d "%~dp0"
cls
echo ===================================================================
echo             سرور مرکزی و پایگاه داده حسابداری مَه
echo ===================================================================
echo  در حال اجرای سرور داخلی پرتابل روی پورت 3000...
echo  (این پنجره را نبندید تا سایر کامپیوترها بتوانند وصل شوند)
echo ===================================================================

if exist "bin\node.exe" (
    start "" "bin\node.exe" "app\server.bundle.js"
) else (
    node "app\server.bundle.js"
)

timeout /t 2 >nul

:: Open browser
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="http://localhost:3000" --window-size=1366,768
    exit /b 0
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app="http://localhost:3000" --window-size=1366,768
    exit /b 0
)
start "" "http://localhost:3000"
